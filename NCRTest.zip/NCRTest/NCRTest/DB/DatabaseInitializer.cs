﻿using NCRTest.ErrorsLog;
using NCRTest.Model;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCRTest.DB
{
    public class DatabaseInitializer
    {
        public static void InitializeDatabase()
        {
            try
            {
                using (var connection = new SQLiteConnection(ConfigurationClass.SQLConnection))
                {
                    connection.Open();

                    // Create HardwareTypes table
                    using (var cmd = new SQLiteCommand(
                        "CREATE TABLE IF NOT EXISTS HardwareTypes (Id TEXT PRIMARY KEY, Model TEXT, AdditionalInfo TEXT)",
                        connection))
                    {
                        cmd.ExecuteNonQuery();
                    }

                    // Create Records table
                    using (var cmd = new SQLiteCommand(
                        "CREATE TABLE IF NOT EXISTS Records (Id INTEGER PRIMARY KEY, HardwareTypeId TEXT, Value TEXT, CreateDate DATETIME, FOREIGN KEY(HardwareTypeId) REFERENCES HardwareTypes(Id))",
                        connection))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }

        }
        #region HardwareTypeTable
        public static void InsertHardwareType(string Id, string Model, string AdditionalInfo)
        {
            try
            {
                using (var connection = new SQLiteConnection(ConfigurationClass.SQLConnection))
                {
                    connection.Open();

                    using (var cmd = new SQLiteCommand(
                        "INSERT INTO HardwareTypes (Id,Model, AdditionalInfo) VALUES (@Id,@Model, @AdditionalInfo)",
                        connection))
                    {
                        cmd.Parameters.AddWithValue("@Id", Id);
                        cmd.Parameters.AddWithValue("@Model", Model);
                        cmd.Parameters.AddWithValue("@AdditionalInfo", AdditionalInfo);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }

        }
        public static List<HardwareModel> GetHardwareType()
        {
            try
            {
                string connectionString = ConfigurationClass.SQLConnection;
                List<HardwareModel> list = new List<HardwareModel>();
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    string selectQuery = "SELECT Id, Model, AdditionalInfo FROM HardwareTypes";

                    connection.Open();

                    using (SQLiteCommand command = new SQLiteCommand(selectQuery, connection))
                    {
                        using (SQLiteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                HardwareModel htm = new HardwareModel();
                                htm.Id = reader["Id"].ToString();
                                htm.Model = reader["Model"].ToString();
                                htm.AdditionalInfo = reader["AdditionalInfo"].ToString();

                                list.Add(htm);
                            }
                        }
                    }
                }
                return list;
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
                return null;
            }

        }
        public static void DeleteHardwareType()
        {
            try
            {
                string connectionString = ConfigurationClass.SQLConnection;
                List<HardwareModel> list = new List<HardwareModel>();
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    string selectQuery = "DELETE FROM HardwareTypes";

                    connection.Open();

                    using (SQLiteCommand command = new SQLiteCommand(selectQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }


        }
        public static bool CheckIfAlreadyExistHardwareType()
        {
            try
            {
                string connectionString = ConfigurationClass.SQLConnection;
                List<HardwareModel> list = new List<HardwareModel>();
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    string selectQuery = "SELECT Id, Model, AdditionalInfo FROM HardwareTypes";

                    connection.Open();

                    using (SQLiteCommand command = new SQLiteCommand(selectQuery, connection))
                    {
                        using (SQLiteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
                return false;
            }

        }
        #endregion
        #region RecorTable
        public static void InsertRecord(string HardwareTypeId, string Value)
        {
            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(ConfigurationClass.SQLConnection))
                {
                    connection.Open();


                    DateTime createDate = DateTime.Now;

                    string insertQuery = @"
                    INSERT INTO Records (HardwareTypeId, Value, CreateDate)
                    VALUES (@HardwareTypeId, @Value, @CreateDate)";

                    using (SQLiteCommand command = new SQLiteCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@HardwareTypeId", HardwareTypeId);
                        command.Parameters.AddWithValue("@Value", Value);
                        command.Parameters.AddWithValue("@CreateDate", createDate);

                        int rowsAffected = command.ExecuteNonQuery();


                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }

        }
        public static List<RecordModel> GetRecords(string HardverTypeId)
        {
            try
            {
                string connectionString = ConfigurationClass.SQLConnection;
                List<RecordModel> list = new List<RecordModel>();
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    string selectQuery = "SELECT * FROM Records WHERE HardwareTypeId=@HardwareTypeId";

                    using (SQLiteCommand command = new SQLiteCommand(selectQuery, connection))
                    {
                        command.Parameters.AddWithValue("@HardwareTypeId", HardverTypeId);
                        using (SQLiteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                RecordModel recordModel = new RecordModel();
                                recordModel.ID = reader.GetInt32(0);
                                recordModel.HardwareTypeId = reader.GetString(1);
                                recordModel.Value = reader.GetString(2);
                                recordModel.Created = reader.GetDateTime(3);

                                list.Add(recordModel);
                            }
                        }
                    }
                    return list;
                }
            }

            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
                return null;
            }
        }
        #endregion
    }
}
