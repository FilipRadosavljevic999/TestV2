﻿using NCRTest.DB;
using NCRTest.ErrorsLog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NCRTest.UtilizationFolder
{
    public class Utilization
    {
        private ManagementObjectSearcher _searcher;
        
        #region Utilization
        public void InsertMemoryUtilization()
        {
            try
            {
                _searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");
                foreach (ManagementObject memoryModule in _searcher.Get())
                {
                    PerformanceCounter ramCounter = new PerformanceCounter("Memory", "% Committed Bytes In Use");
                    Thread.Sleep(1000);
                    float ramUtilization = ramCounter.NextValue();
                    DatabaseInitializer.InsertRecord(memoryModule["PartNumber"].ToString().Trim(), ramUtilization.ToString());
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }

        }
        public void InsertProcessorUtilization()
        {
            try
            {
                _searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
                foreach (ManagementObject processor in _searcher.Get())
                {
                    PerformanceCounter cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                    float cpuUsage = cpuCounter.NextValue();
                    System.Threading.Thread.Sleep(1000);
                    cpuUsage = cpuCounter.NextValue();
                    DatabaseInitializer.InsertRecord(processor["ProcessorId"].ToString().Trim(), cpuUsage.ToString());
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }

        }
        public void InsertDiskUtilization()
        {
            try
            {
                _searcher = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
                var counter = 1;//I used counter because maybe the components have the same serial number.
                foreach (ManagementObject disk in _searcher.Get())
                {
                    DriveInfo[] drives = DriveInfo.GetDrives();
                    long sum = 0;
                    foreach (DriveInfo drive in drives)
                    {
                        if (drive.IsReady)
                        {
                            if (drive.DriveType == DriveType.Fixed)
                            {
                                sum += drive.TotalSize - drive.AvailableFreeSpace;
                            }
                        }
                    }
                    DatabaseInitializer.InsertRecord(disk["SerialNumber"].ToString().Trim() + "_" + counter, sum.ToString());
                    counter++;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }

        }
        #endregion
        #region HardwareData
        public void InsertHardwareTypeMemory()
        {
            try
            {
                _searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");
                foreach (ManagementObject memoryModule in _searcher.Get())
                {
                    DatabaseInitializer.InsertHardwareType(memoryModule["PartNumber"].ToString().Trim(), memoryModule["Name"].ToString(), String.Format("Name:{0},PartNumber:{1},Capacity:{2} bytes", memoryModule["Name"], memoryModule["PartNumber"], memoryModule["Capacity"]));
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }

        }
        public void InsertHardwareTypeDisk()
        {
            try
            {
                var counter = 1;
                _searcher = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
                foreach (ManagementObject disk in _searcher.Get())
                {
                    DatabaseInitializer.InsertHardwareType(disk["SerialNumber"].ToString().Trim() + "_" + counter, disk["Model"].ToString(), String.Format("Serial Number:{0},Size:{1} bytes", disk["SerialNumber"], disk["Size"]));
                    counter++;
                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.LogginError(ex);
            }


        }
        public void InsertHardwareTypeProcessor()
        {
            try
            {
                _searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
                foreach (ManagementObject processor in _searcher.Get())
                {
                    DatabaseInitializer.InsertHardwareType(processor["ProcessorId"].ToString().Trim(), processor["Name"].ToString(), String.Format("CPU,Serial Number:{0}", processor["ProcessorId"]));
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }

        }
        #endregion

    }
}
