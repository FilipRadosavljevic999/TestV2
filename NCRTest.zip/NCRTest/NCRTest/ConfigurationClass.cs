﻿using NCRTest.ErrorsLog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCRTest
{
    public static class ConfigurationClass
    {
        public static string SQLConnection { get => "Data Source=MonitoringDatabasev2.db;Version=3;"; }
        public static int MilisecondIntervalForTimer { get => GetFromSettings(); }
        /// <summary>
        /// Get interval from file 
        /// </summary>
        /// <returns></returns>
        private static int GetFromSettings()
        {
            try
            {
                var configFilePath = "Settings.txt";
                if (File.Exists(configFilePath))
                {
                    string[] lines = File.ReadAllLines(configFilePath);
                    string interval = lines[0].Split('=')[1].Trim();
                    return Convert.ToInt32(interval);
                }
                else
                {
                    return 300000;
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
                return 0;
            }
        }
    }
}
